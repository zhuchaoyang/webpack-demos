module.exports = {
  "primary-color": "#38B0B7",

  //link
  "link-color": "#333333",
  "link-hover-color": "#38B0B7",
  "link-active-color": "#38B0B7",
  "link-decoration": "none",
  "link-hover-decoration": "none",
}